package com.example.donation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Donate extends AppCompatActivity {
    private Button donateButton;
    private RadioGroup paymentMethod;
    private ProgressBar progressBar;
    private NumberPicker amountPicker;
    private TextView totalView;

    private int totalDonated = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_donate);

        donateButton = this.findViewById(R.id.donateButton);

        totalView = this.findViewById(R.id.total);

        paymentMethod = this.findViewById(R.id.payment);

        progressBar = this.findViewById(R.id.progressBar);
        progressBar.setMax(10000);

        amountPicker = this.findViewById(R.id.amountPicker);
        amountPicker.setMinValue(0);
        amountPicker.setMaxValue(1000);
    }

    public void donateButtonPressed (View view) {
        int amount = amountPicker.getValue();
        int radioId = paymentMethod.getCheckedRadioButtonId();

        totalDonated += amount;
        progressBar.setProgress(totalDonated);

        String method = "";
        if (radioId == R.id.paypal) {
            method = "PayPal";
        } else {
            method = "Direct";
        }

        totalView.setText("Total so Far: $" +totalDonated);

        Log.v("Donate", "Donate Pressed! with amount " + amount + ", method: " +
                method);
        Log.v("Donate", "Current total " + totalDonated);
    }
}